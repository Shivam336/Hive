package W14_SH_170030;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q5 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection con= DriverManager.getConnection("jdbc:hive2://localhost:10000/jdbc","","");
		Statement stmt=con.createStatement();
		stmt.execute("create table olympic2(AthleteName string,Age Int,Country string,Year Int,Closing_Date string,Sprot string,Gold_Medals int,Silver_Medals int, Bronze_Medals int, Total_Medals int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'");
		System.out.println("Olympic Table Created Successfully");
		con.close();
	}
}