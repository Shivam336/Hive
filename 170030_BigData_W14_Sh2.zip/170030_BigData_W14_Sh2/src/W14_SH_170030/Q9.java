package W14_SH_170030;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q9 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection con= DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
		Statement st2=con.createStatement();
		ResultSet rs2 = st2.executeQuery("select Country,sum(Total_Medals) from olympic group by Country");
		System.out.println("Country ----  Medals");
		while(rs2.next()){
			String Country=rs2.getString(1);
			String Medals=rs2.getString(2);
			System.out.println(Country+" ----  "+Medals);
		}
	}
}