package W14_SH_170030;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q4 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection con= DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select avg(salary) from salary");
		String averageSalary="";
		while(rs.next()){
			averageSalary=rs.getString(1);
		}
		Statement st2=con.createStatement();
		ResultSet rs2 = st2.executeQuery("select emp_id,salary from salary where salary>"+averageSalary+" order by salary desc limit 10");
		while(rs2.next()){
			int id=rs2.getInt(1);
			String salary2=rs2.getString(2);
			System.out.println(id+" ----  "+salary2);
		}
	}
}