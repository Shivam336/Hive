package W14_SH_170030;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q1 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection con= DriverManager.getConnection("jdbc:hive2://localhost:10000/jdbc","","");
		Statement stmt=con.createStatement();
		stmt.execute("create table employee3(empid int,birthday string,f_name string,l_name string,gender varchar(5),work_day string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','");
		System.out.println("Employee Table Created Successfully");
		Statement stmt2=con.createStatement();
		stmt2.execute("create table salary2(empid int,salary string,start_date string,end_date string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','");
		System.out.println("Salary Table Created Successfully");
		con.close();
	}
}